---
name: "identidade-rafael-oliveira-luthier"
description: "Negócio e identidade visual de Rafael Oliveira Luthier (Vilhena-RO): serviços, processo, cores, tom de voz e padrões de post. Use ao criar conteúdo, site ou peças da marca."
---

# Rafael Oliveira | Luthier Vilhena

Fonte: perfil do Instagram @rafaeloliveiraluthier (verificado, ~620 posts, ~2,3 mil seguidores), consultado em out/2026. Confirme dados de contato com o cliente antes de publicar.

## Identidade
- **Nome da marca:** Rafael Oliveira Luthier (assinatura: "Rafael Oliveira" + "Luthier" em script)
- **Nome de exibição:** Rafael Oliveira | Luthier Vilhena
- **@:** rafaeloliveiraluthier (também tem página no Facebook "Rafael Oliveira Luthier")
- **Slogan:** "Cuidado, técnica e paixão em cada detalhe."
- **Promessa (bio):** "Seu instrumento confortável e pronto pra tocar"
- **Local:** Av. Juracy Corrêa Müller, 5393 – Vilhena/RO (atendimento presencial na bancada)
- **WhatsApp visto em post:** (69) 99325-3629 — orçamentos e agendamentos via link da bio

## Modelo de negócio
Luthier autônomo, prestador de serviço local (Vilhena e região do Cone Sul de RO). Receita principal: mão de obra de manutenção e reparo, cobrada por orçamento individual após avaliação do instrumento. Receitas secundárias: troca/venda de componentes e cordas, e conteúdo/publis de equipamentos (ex.: post da pedaleira M-VAVE Tank-G). Captação: Instagram (conteúdo educativo + prova social) → link da bio → WhatsApp → orçamento → agendamento.

## O que faz (serviços)
- 🔧 Regulagem completa (ação, altura de cordas, tensor, oitavas, nut, estabilidade de afinação)
- ⚡ Elétrica e blindagem (captadores, potenciômetros, chaves, ruídos)
- 🪵 Colagens e reparos estruturais (ex.: quebra de headstock, recuperação de acabamento)
- 🧹 Limpeza e manutenção
- 🔩 Troca de componentes (tarraxas, trastes, cordas, pontes)

**Instrumentos:** violões (aço e nylon), guitarras, contrabaixos e violas caipira. Destaques mostram marcas como Condor, Washburn, Giannini, Les Paul, GTR.

## Como trabalha
- Avaliação individual na bancada, "respeitando as características do instrumento e a necessidade de cada músico".
- Diagnóstico explicado ao cliente (o problema nem sempre é a corda: tarraxa, nut, assentamento, regulagem).
- Mostra antes/depois e processo em vídeo; feedbacks de clientes (prints de WhatsApp) nos destaques.
- Valoriza o trabalho técnico frente a pedidos de desconto (humor: "mas não dá pra fazer mais barato?") e o empreendedor que faz tudo (luthier, fotógrafo, marketing, eletrônica, marceneiro…).

## Paleta de cores
| Uso | Cor | Hex aprox. |
|---|---|---|
| Primária / destaque | Laranja vibrante | #F7941D |
| Laranja escuro / gradiente | Laranja queimado | #E2620F |
| Fundo | Preto / quase preto | #0D0D0D |
| Fundo secundário | Grafite | #1E1E1E |
| Texto | Branco | #FFFFFF |
| Apoio natural | Madeira/âmbar (fotos de bancada) | #8B5A2B |

Regra: fundo escuro, palavra-chave em laranja, resto em branco. Logo: círculo preto com borda laranja, "R" estilizado laranja com palheta/headstock, nome em branco e "Luthier" em script laranja.

## Tipografia
- Títulos: sans condensada, bold, caixa alta (estilo Anton/Bebas Neue/Oswald), grandes e impactantes, ocupando o post.
- Assinatura: script cursivo para "Luthier".
- Apoio: sans limpa (Montserrat/Poppins).

## Estilo de foto e post
- Fotos reais de bancada: close em trastes, headstock, tarraxas, captadores, ferramentas; luz quente, fundo escuro desfocado.
- Carrossel padrão: logo no topo esquerdo + slogan pequeno; headline gigante (ex.: "SEU INSTRUMENTO ESTÁ DIFÍCIL DE TOCAR?", "QUEBROU. MAS NÃO ERA O FIM."); subtítulo com a solução; ícones laranja com benefícios; rodapé com nome e "Luthier em Vilhena/RO".
- Reels: bastidores, humor/memes de músico, POV, trends de áudio, antes/depois.
- Ocasionalmente artes de notícia/publi com cores saturadas (amarelo, azul) — exceção, não o padrão.

## Tom de voz
Próximo, técnico mas didático, confiante; primeira pessoa ("na minha bancada"). Estrutura de legenda: pergunta-dor com emoji → explicação do problema → solução/serviço em lista com emojis (🔧⚡🪵🧹🔩) → instrumentos atendidos → 📍 Luthier em Vilhena/RO → 📲 CTA "Solicite seu orçamento pelo link da bio" → assinatura com slogan → hashtags.

**Hashtags base:** #Luthier #LuthierVilhena #VilhenaRO #RegulagemDeInstrumentos #Guitarra #Violao #Contrabaixo #Luthieria

## Pilares de conteúdo
1. Educativo (sinais de que precisa de regulagem, afinação que não segura, cordas aço x nylon)
2. Prova de trabalho (reparos, antes/depois)
3. Prova social (feedbacks)
4. Bastidores e humor da vida de luthier
5. Novidades/publis de equipamentos e mercado (ex.: preço de cordas)